<!DOCTYPE html>
<html>
<head>
    <title>URL Shortner</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.3.1/css/bootstrap.min.css" />
</head>
<body>

<div class="container">

    <h4>Check Short URL</h4>
    <div class="card">
      <div class="card-header">
        <form method="POST" action="<?php echo e(route('shortlink.check')); ?>">
            <?php echo csrf_field(); ?>
            <div class="input-group mb-3">
              <input type="text" name="link" class="form-control" placeholder="Enter URL" aria-label="Recipient's username" aria-describedby="basic-addon2">
              <div class="input-group-append">
                <button class="btn btn-info" type="submit">Check</button>
              </div>
            </div>
        </form>
      </div>

      <?php if($errors->any()): ?>
            <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
            </div>
        <?php endif; ?>
        
      <div class="card-body">

            <?php if(Session::has('error')): ?>
                <div class="alert alert-danger">
                    <p><?php echo e(Session::get('error')); ?></p>
                </div>
            <?php endif; ?>


      </div>
    </div>

</div>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\fingent\resources\views/checkurl.blade.php ENDPATH**/ ?>